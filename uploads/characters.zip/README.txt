經彩青春 SET 角色圖包｜17 張透明背景 PNG

上傳方式：開啟 GitHub Repo 的 uploads 資料夾 → Add file → Upload files → 將整個 ZIP 上傳並命名為 characters.zip。
GitHub Actions 將會自動檢查 17 張固定名稱，解壓縮到 assets/characters/generated/，並啟用網頁人物顯示。
這個 ZIP 不需自行解壓縮。

C01_L01.png　樂樂／基本站姿
C01_L02.png　樂樂／腹痛站姿
C01_L03.png　樂樂／坐姿腹痛
C01_L04.png　樂樂／放心微笑
C01_L05.png　樂樂／教室日常
C01_L06.png　樂樂／健康中心聆聽
C02_Q01.png　小琪／基本站姿
C02_Q02.png　小琪／關心同學
C02_Q03.png　小琪／提問思考
C02_Q04.png　小琪／支持微笑
C03_D01.png　大明／基本站姿
C03_D02.png　大明／好奇提問
C03_D03.png　大明／關心同學
C03_D04.png　大明／友善理解
C04_N01.png　護理師／基本站姿
C04_N02.png　護理師／知識解說
C04_N03.png　護理師／鼓勵微笑
